 ___        __       
|_ _|_ __  / _| ___  
 | || '_ \| |_ / _ \ 
 | || | | |  _| (_) |
|___|_| |_|_|  \___/ 

-- #### Before you run.........

-*To show you the animations i have created one example scene called "Example".

-Controls:

	-To select the character to clone, "a" or "d" to select and "Return" to clone. (you can only clone one character at same time).
	-To select the death mode to kill the character you can select the numbers (1 to 9):
		-"1" shot
		-"2" blade
		-"3" axe
		-"4" weight
		-"5" airpump
		-"6" laser
		-"7" electrocuted
		-"8" acid
		-"9" fire
	
-"Important" you must add the different layers used in this pack, please see the example capture image "addLayers" (addLayers.jpg)
	*All layers you need:
			-Default
			-TransparentFX
			-Water
			-UI
			-MINIME
			-Bullet
			-Player

	*All tags you need:
			-Untagged
			-Respawn
			-EditorOnly
			-MainCamera
			-Player
			-GameController
			-MINIME


Youtube video example: "https://youtu.be/PajuOxmufy0"
You have more info on "How_it_Works.txt"

